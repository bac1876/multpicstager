
export const MAX_FILES = 15;
